<?php
require_once('../db.php');
        if (empty($_SESSION["user"])) {
    echo header('Location:../');
    exit;
}

?>

<html>
<head>

<style>
body {font-family: "Lato", sans-serif;}

.tablink {
    background-color: #4df1cd;
    color: #134e4e;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    font-size: 17px;
    width: 25%;
}




</style>
</head>
<body>


<button class="tablink"><a style="text-decoration: none;" href="welcome.php">GO To DashBoard</a></button>
<button class="tablink"><a style="text-decoration: none;" href="check_user.php">User List</a></button>
<button class="tablink"><a style="text-decoration: none;" href="register.php">Create New User</a></button>
<button class="tablink"><a style="text-decoration: none;" href="index.php" >Logout</a></button>


     
</body>
</html> 

