<?php
require_once '../db.php';

?>