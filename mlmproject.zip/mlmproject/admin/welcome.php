<?php
require_once('../db.php');


?>

<!DOCTYPE html>
<html>
    <head>
<style>
body {font-family: "Lato", sans-serif;}

.tablink {
    background-color: #4df1cd;
    color: #134e4e;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    font-size: 17px;
    width: 25%;
}

.container
{
    text-align: center;
}
a{
    text-decoration: none;
    color: black;
}
button
{
        padding: 10px 19px;
    margin: 14px;
}
</style>

</head>
<body>
    
  <button style="float: right;"><a href="index.php">logout</a></button>


<div class="content" ><h1 style="
    color: #58428a;">
        
        <center>Welcome to GNI Websolution</center><br>
        
        <center>You are Welcome<br>
         <p>Total Amount =><?php
                            $query = "SELECT sum(amount) as sumAB FROM  `wallet` Where user_id = '123456' ";
                           $sumAB = mysqli_fetch_array(mysqli_query($db, $query));
                            if (isset($sumAB['sumAB'])) {
                                echo 'Rs. ' . $sumAB['sumAB'];
                            } else {
                                echo 'Rs. 0';
                            }
                            
                            ?>
                
         </p> <button><a href="paid_user.php">Paid User</a></button></center>
       
        <?php if (isset($_SESSION["send"]))
     
     if ($_SESSION["send"]["status"] == false) echo '<p style="color:red" class="false" >' . $_SESSION['send']['msg'].'</p>'; ?> 
      
        <?php 
              if (isset($_SESSION["send"]))
                   
                  if ($_SESSION["send"]["status"] == true) echo '<p style="color:red" class="true" >' . $_SESSION['send']['msg'].'</p>'; 
        
                    unset($_SESSION["send"]); ?>
        <div class="container">
            <form method="post" action="reg_sub_login.php"> 
            <div>
                <input type="text" name="user_id" placeholder="Enter User Id" required="true">
            </div>
            <div>
                <input type="text" name="amount" placeholder="Enter Ammount" required="true">
            </div>
                <button type="submit" name="send">Send Money</button>
            
        </form>
    
        </div>
      
    
    
    </h1></div>

</body>
</html>