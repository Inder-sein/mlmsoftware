<?php
require_once("db.php");
include("userClass.php");

error_reporting(0);
session_start();
$starter = 1;
$user = new user();

if (isset($_REQUEST["request"])) {
    
    $request = $_REQUEST["request"];
    
    if ($request == "sponser") {
        $uname = $_POST['user_id'];

//sql query to check whether the user name is exist or not
        $sql = "SELECT * FROM user where user_id = '$uname'";
//        echo $sql;die;
        $rows = mysqli_query($db, $sql);
//echo $sql;die;
        
        if (mysqli_num_rows($rows) == 0) {
            echo "<font color='red'>This is not a valid id please check and try again</font>";
        } else {
                $data = mysqli_fetch_assoc($rows);
            echo "Name: <font color='blue'>" . $data['name'] . "</font>";
        }
    }
    if ($request == "mobileCheck") {
        $mobile = $_POST['mobile'];

//sql query to check whether the user name is exist or not
        $sql = "SELECT * FROM user where phone = '$mobile'";
        $rows = mysqli_query($db, $sql);
        if (mysqli_num_rows($rows) >= 3) {
            echo "<font color='red'>This mobile number already used.</font>";
        }
    }
    if ($request == "valid_sponsor") {
        $uname = $_GET['user_id'];
        $position = $_GET['position'];
        $data  = $user->getvalidSponsor($db,$uname,$position);
        $userData = mysqli_fetch_array(mysqli_query($db,"SELECT name FROM user where user_id = '$data'"));
        // echo "Under place sponsor id: <font color='blue'>" . $data . "</font> and name:<font color='blue'>" . $userData['name'] . "</font>";
        $response = array("id" => $data, "msg" => "Under place sponsor id: <font color='blue'>" . $data . "</font> and name:<font color='blue'>" . $userData['name'] . "</font>");
        echo json_encode($response);
        exit();

        
    }
}

//if (isset($_POST["verify-form"])) {
//
//    $token = base64_decode($_POST["token"]);
//
//    $code = $_POST["code"];
//    $query = mysqli_query($db, "select * from `user` WHERE `id`='$token'");
//    $hashData = mysqli_fetch_array($query);
//    
//    $hash = $hashData["hash"];
//    $uid = $hashData['id'];
//    $user_id = $hashData['user_id'];
//    $email = $hashData['email'];
//    $phone = $hashData['phone'];
//    $name = $hashData['name'];
//    $password = $hashData['password'];
//    $master = $hashData['master_key'];
//    if ($hash == $code) {
//
//        $queryUpdate = mysqli_query($db, "UPDATE  `user` SET  `enable` =  '1',`hash`= ' ' WHERE `id`='$token'");
//        if ($queryUpdate) {
//            $_SESSION["login"] = array("msg" => "Your account detail sent in your email , Please login with given detail.", "status" => "true");
//            $date = date("m/d/Y");
//            $receipt_id = strtotime(date("Y/m/d H:i:s"));
//
//             $date= date("d-M-Y");
//            $subjectMail = "[ABtrade]:Account Detail.";
//            $htmlContent = "
//	   <!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
//            <html xmlns='http://www.w3.org/1999/xhtml'>
//            <head>
//            <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
//            <title>Welcome</title>
//            <style>
//            .container
//            {
//                    width:600px;
//                    margin:0 auto;
//            }
//            .logo {
//                    width: 100%;
//                    float: left;
//                    text-align: center;
//                    margin-top: 30px;
//            }
//            .logo img {
//                    width: 44%;
//            }
//            .main-div {
//                    width: 100%;
//                    float: left;
//                    background: #f8f8f8;
//                    padding: 27px;
//                    margin-top: 20px;
//                    margin-bottom: 20px;
//            }
//            td {
//                    border: 1px #ccc solid;
//                    padding: 10px;
//            }
//            .main-div h1 {
//                    color: #f7931b;
//            }
//            </style>
//            </head>
//
//            <body>
//            <div class='container'>
//                <div class='logo'>
//                <img src='https://ABtrade.com/images/logo.png   ' />
//                </div>
//                    <div class='main-div'>
//                            <h1>Login <span style='color:#000;'>Detail</span></h1>
//                        <p>Hello $name,</p>
//                        <p>Your account logged in details.</p>
//
//                        <table style='width:100%'>
//              <tr>
//                <td>Login ID</td>
//                <td>$user_id</td>
//              </tr>
//              <tr>
//                <td>Password</td>
//                <td>$password</td>
//              </tr>
//              <tr>
//                <td>Master Key</td>
//                <td>$master</td>
//              </tr>
//
//                <tr>
//                <td>Date</td>
//                <td>$date</td>
//              </tr>
//            </table>
//
//            <p>If you did not perform this login, immediately <a href='#'>click here</a> to terminate access to your account and then a new generated password will be sent to your email. </p>
//            <p>Once you get your new password, login and change it to something you can remember on <a href='#'>your account page.</a> </p>
//            <p>Thank you,</p>
//             <p>Please check more detail at <a href='https://ABtrade.com/'>www.ABtrade.com</a></p>
//                    </div>
//            </div>
//            </body>
//            </html>
//            ";
//            // Set content-type header for sending HTML email
//            $headers = "MIME-Version: 1.0" . "\r\n";
//            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
//
//            // Additional headers
//            $headers .= 'From: ABtrade<ABtrade.com@gmail.com>' . "\r\n";
//            
//            mail($email, $subjectMail, $htmlContent, $headers);
//                
//                $msg = "Hi " . $name . ", Welcome You to Usbitmining. Your account detail user id:-$user_id, password:- $password, master key:-$master .";
//                $msg = urlencode($msg);
//                $url = $baseurl . 'user=' . $userkey . '&&key=' . $key . '&&mobile=' . $phone . '&&senderid=' . $senderid . '&&message=' . $msg . '&&accusage=1';
//               
//                $user->curl_get_contents($url);
//                
//                header("location:../thanks.php?e=".base64_encode($email));die;
//            //send mail
//        }
//        $_SESSION["verify"] = array("msg" => "Somthing went wrong, Please try again.", "status" => "false");
//        header("location:../email_verification.php?u=" . $_POST['token']);
//        die;
//    } else {
//        $_SESSION["verify"] = array("msg" => "Your verification code is incorrect.", "status" => "false");
//        header("location:../email_verification.php?u=" . $_POST['token']);
//        die;
//    }
//}

//if (isset($_POST["login_form"])) {
////    die("Sorry, Site is under maintanace, Please visit again few hour later.");
//    $user = $_POST['user_id'];
//    $pass = $_POST['password'];
//
//    $query = mysqli_query($db, "select * from user where (email='$user' || user_id='$user') && enable=1 ");
//
//    if (mysqli_num_rows($query) > 0) {
//        $user = mysqli_fetch_array($query);
//        if ($user["password"] == $pass) {
//            if ($user["role"] == "user") {
//                $_SESSION['user'] = $user;
//
//
////		$_SESSION["login"]=array('msg'=>'Login Suceess !','status'=>'true');
//                header("location:../Dashboard");
//                die;
//            }
//        }
//    }
//    $_SESSION["login"] = array('msg' => 'Invalid Credential!', 'status' => 'false');
//    header("location:../login.php");
//    die;



//    echo json_encode($_POST);
//    die;
//}
//if(isset($_POST['forget'])){
//    $email = $_POST['user_id'];
//    $query1 = mysqli_query($db,"select * from `user` where email='$email' or user_id='$email'");
//    $count= mysqli_num_rows($query1);
//    $data1 = mysqli_fetch_array($query1);
//    
//    if($count>0){
//         $name = $data1["name"];
//         $password = $data1["password"];
//         $userId = $data1["user_id"];
//         $master_key = $data1["master_key"];
//         $phone = $data1["phone"];
//        $subjectMail ="[thesmartchoice]"; 
//         $htmlContent = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
//                        <html xmlns='http://www.w3.org/1999/xhtml'>
//                        <head>
//                        <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
//                        <title>Welcome</title>
//                        <style>
//                        .container
//                        {
//                                width:600px;
//                                margin:0 auto;
//                        }
//                        .logo {
//                                width: 100%;
//                                float: left;
//                                text-align: center;
//                                margin-top: 30px;
//                        }
//                        .logo img {
//                                width: 44%;
//                        }
//                        .main-div {
//                                width: 100%;
//                                float: left;
//                                background: #f8f8f8;
//                                padding: 27px;
//                                margin-top: 20px;
//                                margin-bottom: 20px;
//                        }
//                        td {
//                                border: 1px #ccc solid;
//                                padding: 10px;
//                        }
//                        .main-div h1 {
//                                color: #f7931b;
//                        }
//                        </style>
//                        </head>
//
//                        <body>
//                        <div class='container'>
//                            <div class='logo'>
//                            <img src='http://thesmartchoice.in/images/logo.png' style='width:30%' />
//                            </div>
//                                <div class='main-div'>
//                                        <h1>Account <span style='color:#000;'>OTP</span></h1>
//                                    <p>Hello ,</p>
//                                    <p>Please activate your account.</p>
//
//                                    <table style='width:100%'>
//                          <tr>
//                            <td>Name</td>
//                            <td>$name</td>
//                          </tr>
//                          <tr>
//                            <td>User Id</td>
//                            <td>$userId</td>
//                          </tr>
//                          <tr>
//                            <td>Password</td>
//                            <td>$password</td>
//                          </tr>
//                          <tr>
//                            <td>Master Key</td>
//                            <td>$master_key</td>
//                          </tr>
//                        </table>
//                        <p>Please check more detail at <a href='http://thesmartchoice.in'>http://thesmartchoice.in</a></p>
//                        </div>
//                        </div>
//                        </body>
//                        </html>
//                        ";
//        // Set content-type header for sending HTML email
//        $headers = "MIME-Version: 1.0" . "\r\n";
//        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
//
//        // Additional headers
//        $headers .= 'From: <thesmartchoice.in@gmail.com>' . "\r\n";
//        
//
//        mail($email, $subjectMail, $htmlContent, $headers);
//        
//        
//       
//        $msg = "Hi ! $name, welcome You to thesmartchoice. Your username $userId and password $password and master key $master_key. For Any query visit www.thesmartchoice.in";
//        $msg = urlencode($msg);
//        $url = $baseurl . 'user=' . $userkey . '&&key=' . $key . '&&mobile=' . $phone . '&&senderid=' . $senderid . '&&message=' . $msg . '&&accusage=1';
//       
//        curl_get_contents($url);
//        
//        $_SESSION["login"]=array('msg'=>'Your password has beeen sent in your email and mobile please check  !','status'=>'true');
//        header("location:../login.php");
//    }else{
//        $_SESSION["forget"]=array('msg'=>'Please enter register email!','status'=>'false');
//        header("location:../forgot-password.php");
//    }
//}
//function curl_get_contents($url) {
//        $ch = curl_init();
//        curl_setopt($ch, CURLOPT_HEADER, 0);
//        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//        curl_setopt($ch, CURLOPT_URL, $url);
//        $data = curl_exec($ch);
//        curl_close($ch);
//       // print_r($data);die;
//        return "";
//    }
?>