<?php
require_once '../db.php';
require_once 'header.php';
?>

            
           <?php



      $q = "select * from user";
      $run = mysqli_query($db,$q);

?>
<html>
    <head>
        
        <style>
            table
            {
                    padding: 85px;
            }
            tr
            {
                background-color: #00ffcc;
    color: #134e4e;
            }
        </style>
    </head>
    <body>

<center>
   
    
<table  border="solid" cellspacing="0" >
       
          <tr>
            
            <th>ID</th>
            <th>name</th>
            <th>User_id</th>
            <th>Role</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Password</th>
            <th>Sponsor</th>
            <th>Position</th>
            <th>Sponser_by</th>
            <th>Address</th>
            <th>City</th>
            <th>Date</th>
            <th>Edit</th>
             
			
			
          </tr>
       	<?php
              while ($row=mysqli_fetch_array($run)) {
                
                $id = $row['id'];
                $name = $row['name'];
                $user_id = $row['user_id'];
                $role= $row['role'];
                $phone = $row['phone'];
                $email = $row['email'];
                $password = $row['password'];
                $sponser = $row['sponsor'];
                $position = $row['position'];
                $sponser_by = $row['sponser_by']; 
                $address = $row['address'];
                $city = $row['city'];
                $date = $row['createAt'];
		?>
                <tr>
                                            	
                    <td style="text-align: center"><?php echo $id; ?></td> 
                    <td style="text-align: center"><?php echo $name; ?></td> 
                    <td style="text-align: center"><?php echo $user_id;?></td> 
                    <td style="text-align: center"><?php echo $role; ?></td>
                    <td style="text-align: center"><?php echo $phone; ?></td>
                    <td style="text-align: center"><?php echo $email; ?></td>
                    <td style="text-align: center"><?php echo $password; ?></td>
                    <td style="text-align: center"><?php echo $sponser; ?></td>
                    <td style="text-align: center"><?php echo $position; ?></td>
                     <td style="text-align: center"><?php echo $sponser_by;?></td>
                   
                    <td style="text-align: center"><?php echo $address; ?></td>
                    <td style="text-align: center"><?php  echo $city; ?> </td>
                    <td style="text-align: center"><?php  echo $date; ?></td>
                     <td style="text-align: center"><a href="edit.php?edit=<?php echo $id; ?>">Edit</a></td>
                    
                    
                   

			    </tr>

              	<?php
              }

    	?>
        
      </table>
</center>
</body>

<center><h2>Design and developed by<a style="text-decoration: none;" href="http://gnimlm.com"> GNI DEVELOPERS</a></h2></center>
        </html>
      
