<?php
//require_once('../db.php');
require_once 'header.php';

      $q = "select * from new";
      $run = mysqli_query($conn,$q);

?>
<html>
    <head>
        
        <style>
            table
            {
                    padding: 85px;
            }
            tr
            {
                background-color: #00ffcc;
    color: #134e4e;
            }
        </style>
    </head>
    <body>

<center>
    <form>
        GNI Search:-><input type="text" name ="search" required="true">
        <input type="submit" name="submit" value=">>">
        
        
        
    </form>
    
<table  border="solid" cellspacing="0" >
       
          <tr>
            
            <th>ID</th>
            <th>Reference</th>
            <th>First Name</th>
            <th>Last Name</th>
           
            <th>Email</th>
              <th>Mobile</th>
              <th>State</th>
              <th>City</th>
              <th>Address</th>
              <th>Username</th>
              <th>Edit</th>
              <th>Delete</th>
              <th>Status</th>
              <th>Status</th>
			
			
          </tr>
       	<?php
              while ($row=mysqli_fetch_array($run)) {
                
                $id = $row['id'];
                $reference = $row['reference'];
                $first_name = $row['first_name'];
                $last_name= $row['last_name'];
                $email = $row['email'];
                $phone = $row['phone'];
                $state = $row['state'];
                $city = $row['city'];
                $address = $row['address'];
                $username = $row['username'];        
		?>
                <tr>
                                            	
                    <td style="text-align: center"><?php echo $id; ?></td> 
                    <td style="text-align: center"><?php echo $reference; ?></td> 
                    <td style="text-align: center"><?php echo $first_name; ?></td> 
                    <td style="text-align: center"><?php echo $last_name; ?></td>
                    <td style="text-align: center"><?php echo $email; ?></td>
                    <td style="text-align: center"><?php echo $phone; ?></td>
                    <td style="text-align: center"><?php echo $state; ?></td>
                    <td style="text-align: center"><?php echo $city; ?></td>
                    <td style="text-align: center"><?php echo $address; ?></td>
                     <td style="text-align: center"><?php echo $username; ?></td>
                    <td style="text-align: center"><a href="edit.php?edit=<?php echo $id; ?>">Edit</a></td>
                    <td style="text-align: center"><a href="delete.php?delete=<?php echo $id; ?>">Delete</a></td>
                    <td style="text-align: center"><a href="status.php?get=<?php  echo $id; ?>">Add </a></td>
                    <td style="text-align: center"><a href="view_status.php?set=<?php  echo $id; ?>">View Status</a></td>
                    
                    
                   

			    </tr>

              	<?php
              }

    	?>
        
      </table>
</center>
</body>

<center><h2>Design and developed by<a style="text-decoration: none;" href="http://gnimlm.com"> GNI DEVELOPERS</a></h2></center>
        </html>
      
