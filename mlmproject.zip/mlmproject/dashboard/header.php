<?php
require_once('../db.php');
        if (empty($_SESSION["user"])) {
    echo header('Location:../');
    exit;
}

?>

<html>
<head>

<style>
body {font-family: "Lato", sans-serif; width: 100%;}



.dropbtn {
    background-color: #4CAF50;
    color: white;
   padding: 34px;
    font-size: 19px;
    border: none;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: white;
    background-color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #4CAF50;}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: #3e8e41;
}
a{
    color: white;
    text-decoration: none;
}


</style>
</head>
<body>


<!--<button class="tablink"><a style="text-decoration: none;" href="welcome.php">GO To DashBoard</a></button>
<button class="tablink"><a style="text-decoration: none;" href="check_user.php">User</a></button>-->
<div class="dropdown">
  <button class="dropbtn"> <a href="welcome.php">Dashboard</a></button>
<!--  <div class="dropdown-content">
  </div>-->
</div>
<div class="dropdown">
  <button class="dropbtn">Users</button>
  <div class="dropdown-content">
    <a href="all_user.php">All Users</a>
    <a href="paid_user.php">Paid User</a>
   
  </div>
</div>
<div class="dropdown">
  <button class="dropbtn">Withdraw</button>
  <div class="dropdown-content">
    <a href="#">Pending Request</a>
    <a href="#">Withdraw</a>
    
  </div>
</div>
<div class="dropdown">
  <button class="dropbtn">Transactions</button>
  <div class="dropdown-content">
    <a href="#">Wallet Transaction</a>
    
  </div>
</div>
<div class="dropdown">
  <button class="dropbtn">Package</button>
  <div class="dropdown-content">
    <a href="#">Add Package</a>
    <a href="#">View Package</a>
   
  </div>
</div>
<div class="dropdown">
  <button class="dropbtn">Other</button>
  <div class="dropdown-content">
    <a href="#">Latest News</a>
    <a href="#">Testimonial</a>
    <a href="#">Latest Archivers</a>
  </div>
</div>
<div class="dropdown">
  <button class="dropbtn">GNI Wallet</button>
  <div class="dropdown-content">
      <a href="send_money.php">GNI Send Fund</a>
      <a href="#">GNI Fund Detail   </a>
    <a href="#">Add Fund Detail</a>
  </div>
</div>
<div class="dropdown">
  <button class="dropbtn">Send SMS</button>
<!--  <div class="dropdown-content">
   
  </div>-->
</div>
<div class="dropdown">
  <button class="dropbtn">Support</button>
  <div class="dropdown-content">
    <a href="#">Query Pending</a>
    <a href="#">Query Done</a>
    
  </div>
</div>
<!--<button class="tablink"><a style="text-decoration: none;" href="register.php">Create New User</a></button>
<button class="tablink"><a style="text-decoration: none;" href="index.php" >Logout</a></button>-->


     
</body>
</html> 

