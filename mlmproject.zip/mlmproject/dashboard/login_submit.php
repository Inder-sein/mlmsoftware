<?php
require_once '../db.php';
?>

<?php
$user_id = $_POST['user_id'];
$password = $_POST['password'];
 $upcheck = "select * from `user` where user_id='$user_id' AND password='$password'";
   


   $result = $db->query($upcheck);

        if ($result -> num_rows > 0){
            
            $user = mysqli_fetch_array($result);
            
        if ($user["user_id"] == $user_id) {
            
            if ($user["password"] == "$password") {
                
                $_SESSION['user'] = $user;
                

	
                header('Location:welcome.php'); 
                die;
            }
        }
    
        }

     
      
     
    else {
                        

        $_SESSION['log'] = array('msg' => 'Username or Password is incorrect Please try again later....','status' => false);
            header('Location:index.php');
}

?>





