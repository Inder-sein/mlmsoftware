<?php
require_once '../db.php';
require_once 'header.php';
?>

            
           <?php



      $q = "select * from `wallet`";
      $run = mysqli_query($db,$q);

?>
<html>
    <head>
        
        <style>
            table
            {
                    padding: 85px;
            }
            tr
            {
                background-color: #00ffcc;
    color: #134e4e;
            }
        </style>
    </head>
    <body>

<center>
    <form>
        GNI Search:-><input type="text" name ="search" required="true">
        <input type="submit" name="submit" value=">>">
        
        
        
    </form>
    
<table  border="solid" cellspacing="0" >
       
          <tr>
            
            <th>ID</th>
            <th>user_id</th>
            <th>Amount</th>
            <th>From_user_id</th>
            <th>Level</th>
            <th>Description</th>
            <th>Type</th>
            <th>Date</th>
            <th>Edit</th>
             
			
			
          </tr>
       	<?php
              while ($row=mysqli_fetch_array($run)) {
                
                $id = $row['id'];
                $user_id = $row['user_id'];
                $amount = $row['amount'];
                $From_User_Id= $row['from_user_id'];
                $level = $row['level'];
                $description = $row['description'];
                $type = $row['type'];
                $date = $row['createdAt'];
                
		?>
                <tr>
                                            	
                    <td style="text-align: center"><?php echo $id; ?></td> 
                    <td style="text-align: center"><?php echo $user_id; ?></td> 
                    <td style="text-align: center"><?php echo $amount;?></td> 
                    <td style="text-align: center"><?php echo $From_User_Id; ?></td>
                    <td style="text-align: center"><?php echo $level; ?></td>
                    <td style="text-align: center"><?php echo $description; ?></td>
                    <td style="text-align: center"><?php echo $type; ?></td>
                    <td style="text-align: center"><?php echo $date; ?></td>
                    
                     <td style="text-align: center"><a href="edit.php?edit=<?php echo $id; ?>">Edit</a></td>
                    
                    
                   

			    </tr>

              	<?php
              }

    	?>
        
      </table>
</center>
</body>

<center><h2>Design and developed by<a style="text-decoration: none;" href="http://gnimlm.com"> GNI DEVELOPERS</a></h2></center>
        </html>
      
