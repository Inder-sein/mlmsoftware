<?php
require_once '../db.php';
require_once 'userClass.php';
//die("hii");

?>
<?php
$user = new userlogin();

if (isset($_POST["send"])) {
    extract($_POST);
} {
  
    
     $value = $user->extract_post($db, $_POST);
    extract($value);
    // Sponsor id check condition 
    $sponsercheck = mysqli_num_rows(mysqli_query($db, "select user_id from `user` where `user_id` = '$user_id'"));
    if ($sponsercheck == 0) {
        $_SESSION["send"] = array("msg" => "<h3><center>User ID  is not valid please check and try again Later.</center></h3>", "status" => false);
        header("location:welcome.php");exit();
    }
//    $rightSponsor = $under_place;
   $user_id = $_POST['user_id'];
   $amount = $_POST['amount'];
    
  $query = "INSERT INTO `wallet`(`user_id`, `amount`, `description`, `type`) VALUES ('$user_id','$amount','khali','1')";
    $run = mysqli_query($db,$query);
    header('Location:welcome.php');
}

?>