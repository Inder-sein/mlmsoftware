<?php
require_once '../db.php';

?>
<html>
    <head>
        <title>Send Money</title>
        <style>
            a{
                    text-decoration: none;
    padding: 77px;
    margin: 58px 63px 16px 70px;
            }
            </style>
        
    </head>
    <body>
        <h1>
            Your Money Has Been Send
          
        </h1>
        <h2><a href="welcome.php">GO Back</a></h2>
    </body>    
    
    
    
</html>
