<?php
require_once '../db.php';
require_once 'header.php';

?>

<?php if (isset($_SESSION["send"]))
     
     if ($_SESSION["send"]["status"] == false) echo '<p style="color:red" class="false" >' . $_SESSION['send']['msg'].'</p>'; ?> 
      
        <?php 
              if (isset($_SESSION["send"]))
                   
                  if ($_SESSION["send"]["status"] == true) echo '<p style="color:red" class="true" >' . $_SESSION['send']['msg'].'</p>'; 
        
                    unset($_SESSION["send"]); ?>
        <div class="container">
            <center>  <form method="post" action="reg_sub_login.php"> 
            <div>
                <input type="text" name="user_id" placeholder="Enter User Id" required="true"><br><br>
            </div>
            <div>
                <input type="text" name="amount" placeholder="Enter Ammount" required="true">
            </div>
                <button style="width: 50%" type="submit" name="send">Send Money</button>
            
        </form></center>
            
           <head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}

/* Full-width input fields */
input[type=text], input[type=password] {
    width: 50%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
    text-align: center;
}

/* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 20px 20px;
    margin: 10px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

button:hover {
    opacity: 0.8;
}
.container {
    padding: 50px;
}
</style>
</head>