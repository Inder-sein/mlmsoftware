<?php
require_once('../db.php');
require_once ('header.php');

?>

<!DOCTYPE html>
<html>
    <head>
        <style>
.box{
height:150px;
width: 200px;
background-color: black;    
text-align: center;
color: white;
}
</style>

</head>
<body>
    
  


<div class="content" ><h1 style="
    color: #58428a;">
        
        <div class="box">
         <p1 style="padding: 8px 8px;">Total Amount <?php
                            $query = "SELECT sum(amount) as sumAB FROM  `wallet` Where user_id = '123456' ";
                           $sumAB = mysqli_fetch_array(mysqli_query($db, $query));
                            if (isset($sumAB['sumAB'])) {
                                echo 'Rs. ' . $sumAB['sumAB'];
                            } else {
                                echo 'Rs. 0';
                            }
                            
                            ?>
                </div>
         
       
        <?php // if (isset($_SESSION["send"]))
     
   //  if ($_SESSION["send"]["status"] == false) echo '<p style="color:red" class="false" >' . $_SESSION['send']['msg'].'</p>'; ?> 
      
        <?php 
             // if (isset($_SESSION["send"]))
                   
                  //if ($_SESSION["send"]["status"] == true) echo '<p style="color:red" class="true" >' . $_SESSION['send']['msg'].'</p>'; 
        
                    //unset($_SESSION["send"]); ?>
<!--        <div class="container">
            <form method="post" action="reg_sub_login.php"> 
            <div>
                <input type="text" name="user_id" placeholder="Enter User Id" required="true"><br><br>
            </div>
            <div>
                <input type="text" name="amount" placeholder="Enter Ammount" required="true">
            </div>
                <button type="submit" name="send">Send Money</button>
            
        </form>
    
        </div>
      
    
    
    </h1></div>

</body>
</html>-->