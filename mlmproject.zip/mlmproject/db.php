<?php
$db =  mysqli_connect("localhost","root","password","mlmproject");

// Check connection

session_start();
//if (empty($_SESSION["user"])) {
//
//    header("location:index.php");
//
//}



?>
