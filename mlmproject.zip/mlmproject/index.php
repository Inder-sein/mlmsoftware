<?php
require_once 'db.php';
if (isset($_GET['sponsor'])) {
    $refrence = urldecode($_GET['sponsor']);
    $position = urldecode($_GET['position']);
    $q = "select user_id from `user` where `user`.`user_id` = '$refrence'";
    $run =  mysqli_query($db,$q);
    $queryData = mysqli_fetch_array($q);
}

?>


<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Registration Form</title>
  <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.0/css/materialize.min.css'>
<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/icon?family=Material+Icons'>

      <link rel="stylesheet" href="css/style.css">

     
</head>

<body>
     <?php if (isset($_SESSION['m'])) echo decryptString($_SESSION['m']); ?>

<!--  <body ng-controller="RegisterCtrl" ng-app="myApp">-->
  <div class = "container">
      <?php if(isset($_SESSION["register"]))
          if($_SESSION["register"]["status"]== false) echo "<p style='color:red' class='false'>" . $_SESSION["register"]["msg"]. "</p>";  ?>
      <?php if(isset($_SESSION["register"]))
          if($_SESSION["register"]["status"]==true) echo "<p id='response-msg' class='true'>" . $_SESSION['register']['msg']. "</p>";unset($_SESSION["register"]); ?>
    <div id="signup">
      <div class="signup-screen">
        <div class="space-bot text-center">
          <h1>Register Form</h1>
          <div class="divider"></div>
        </div>
          <form method="post" action="register_submit.php">
              <p><div class="input-field col s6">
            <input type="text" name="sponsor" <?php
                                    if (isset($_GET['sponser'])) {
                                        echo 'value="' . $_GET['sponser'] . '"';
                                    }
                                    ?> id="sponsor" onChange="checkSponsor()" onFocus="checkSponsor()" required >
            <label for="sponser">Sponser ID</label>
              </div></p>
                <div id="usernamechk">
                                    <p></p>
                                </div>
                               
                                <div id="validSponsor">
                                    <p></p>

                                </div>
              <p>
                  <div class="input-field col s6">
          <select style="display: block; background-color: #2c3a40; color:#999b8d;" name="position_user">
               <option value="">- Select Position -
                        </option>
                        <option value="left"  
                                <?php
                        if (isset($_GET['position'])) {
                        if ($_GET['position'] == "left") {
                        echo "selected";
                        }
                     }
                        ?> >Left
                        </option>
                      <option value="right" 
                              <?php
                      if (isset($_GET['position'])) {
                      if ($_GET['position'] == "right") {
                      echo "selected";
                     }
                     }
                      ?> > Right
                      </option>
           </select>
          
          </div>
<!--              <div class="input-field col s6">
                  <select ">
                      <option>Name</option>
                      <option>Class</option>
                      <option>Roll Number</option>
                      
                  </select>
              </div>-->
          <div class="input-field col s6">
            <input type="text" name="name" id="textfield2" required>
            <label for="last-name">Full Name</label>
          </div>
          </p>
          <p>
          <div class="input-field col s6">
            <input id="phone" type="text" name="phone" id="mobile" onChange="mobileCheck()" onFocus="mobileCheck()" style='width:100%'  minlength="10" maxlength="14" required>
            <label for="mobile">Mobile No</label>
          </div>
          </p>
          <div id="mobileCheck">
                                    <p></p>
                                </div>
          <div class="input-field col s6">
            <input type="email" name="email"  required>
            <label for="email">Enter Email</label>
          </div>
          <div class="input-field col s6">
            <input type="text" name="address"  required>
            <label for="address">Enter Your Address</label>
          </div>
          
          <div class="input-field col s6">
            <input type="password" name="password" id="textfield" required>
            <label for="password">Password</label>
          </div>
          <div class="input-field col s6">
            <input type="password" name="cpassword" id="textfield" required>
            <label for="password">Confirm Password</label>
          </div>
      
          
          <div class="space-top text-center">
           <button  name="register" class="waves-effect waves-light btn done">
                Register Here
               </button>
            
          </div>
        </form>
          
      </div>
        
    </div>
     
  </div>
</body>
  <script src='https://code.jquery.com/jquery-2.1.4.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.0/js/materialize.min.js'></script>
<script src='https://ajax.googleapis.com/ajax/libs/angularjs/1.4.5/angular.min.js'></script>

  

</body>

</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.js"></script>
<script src="//ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>

<script type="text/javascript">
    validSponsor();
function checkSponsor() { 
    uname = document.getElementById("sponsor").value;
    var params = "user_id=" + uname;
    var url = "ajax.php?request=sponser";
    $.ajax({
    type: 'POST',
            url: url,
            dataType: 'html',
            data: params,
            beforeSend: function() {
            document.getElementById("usernamechk").innerHTML = 'checking';
            $('#pay_sponsor').val(uname);
            },
            complete: function() {

            },
            success: function(html) {

            document.getElementById("usernamechk").innerHTML = html;
            $('#pay_sponsor').val(uname);
            }
    });
}
function validSponsor() { 
   
    uname = document.getElementById("sponsor").value;
    position = document.getElementById("position").value;
    var params = "user_id=" + uname+"&position="+position;
    var url = "ajax.php?request=valid_sponsor";
    $.ajax({
    type: 'GET',
            url: url,
            dataType: 'html',
            data: params,
            beforeSend: function() {
            document.getElementById("validSponsor").innerHTML = 'checking';
//            $('#pay_sponsor').val(uname);
            },
            complete: function() {

            },
            success: function(html) {
                var data = JSON.parse(html);
                if(data != 'undefined'){
                var id = data['id']; 
                var msg = data['msg'];
            document.getElementById("validSponsor").innerHTML = msg;
            document.getElementById("validSponsorInput").value = id;
        }
//            $('#pay_sponsor').val(uname);
            }
    });
}
function mobileCheck() { 
   
    mobile = document.getElementById("mobile").value;
    var params = "mobile=" + mobile;
    var url = "ajax.php?request=mobileCheck";
    $.ajax({
    type: 'POST',
            url: url,
            dataType: 'html',
            data: params,
            beforeSend: function() {
            document.getElementById("mobileCheck").innerHTML = 'checking';
//            $('#pay_sponsor').val(uname);
            },
            complete: function() {

            },
            success: function(html) {

            document.getElementById("mobileCheck").innerHTML = html;
//            $('#pay_sponsor').val(uname);
            }
    });
}
</script>