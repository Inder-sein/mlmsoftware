<?php

require_once("../db.php");

require_once("userClass.php");

if (empty($_SESSION["user"]))  {

    header("location:index.php");

}

$userClass = new user();

$ref = urlencode($_SESSION['user_id']['password']);
//print_r($_SESSION);die;
$id = $_SESSION["user"]['id'];
$userData = $_SESSION["user"];
//$name = $userClass->getUserUserName($conn,$id);


$query = mysqli_query($db, "SELECT * FROM `user` WHERE id='$id'");

$userData = mysqli_fetch_array($query);



$user_id = $_SESSION["user_id"]["password"];

?>

<?php
$name = $userClass->getUserUserName($db, $id);
$user_id = $userClass->getUserUserid($db,$id);
$role = $userClass->getUserUserRole($db,$id);
$phone = $userClass->getUserUserPhone($db,$id);
$email = $userClass->getUserUserEmail($db,$id);
$father_name = $userClass->getUserUserFather_name($db,$id);
$sponsorr = $userClass->getUserUserSponsor($db,$id);
$position = $userClass->getUserUserPosition($db,$id);
$sponser_by = $userClass->getUserUserSponser_by($db,$id);
$address = $userClass->getUserUserAddress($db,$id);
$city = $userClass->getUserUserCity($db,$id); 
$creationDate = $userClass->getUserUserCreateDate($db,$id);
$updatetionDate = $userClass->getUserUserUpdateDate($db,$id);   

?>
