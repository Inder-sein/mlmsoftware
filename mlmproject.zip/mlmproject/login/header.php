<?php
require_once('../db.php');
        if (empty($_SESSION["user"])) {
    echo header('Location:../');
    exit;
}

?>

<html>
<head>

<style>
body {font-family: "Lato", sans-serif; width: 100%;}



.dropbtn {
    background-color: #4CAF50;
    color: white;
   padding: 29px;
    font-size: 19px;
    border: none;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: white;
    background-color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #4CAF50;}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: #3e8e41;
}
a{
    color: white;
    text-decoration: none;
}


</style>
</head>
<body>


<!--<button class="tablink"><a style="text-decoration: none;" href="welcome.php">GO To DashBoard</a></button>
<button class="tablink"><a style="text-decoration: none;" href="check_user.php">User</a></button>-->
<div class="dropdown">
    <button class="dropbtn"> <a style="color:white;" href="welcome.php">Dashboard</a></button>
<!--  <div class="dropdown-content">
  </div>-->
</div>
<div class="dropdown">
  <button class="dropbtn">Personal Data</button>
  <div class="dropdown-content">
    <a href="all_user.php">Topup Your ID</a>
    <a href="upgrade_user.php">Topup User ID</a>
     <a href="paid_user.php">My Other</a>
      <a href="paid_user.php">Accounting Setting</a>
   
  </div>
</div>
<div class="dropdown">
  <button class="dropbtn">Network</button>
  <div class="dropdown-content">
    <a href="#">My Direct List</a>
    <a href="#">Single Leg Downline</a>
    <a href="#">Level View</a>
    <a href="#">Level Downline</a>
    <a href="#">Level Tree View</a>
    
  </div>
</div>
<div class="dropdown">
  <button class="dropbtn">Income Summary</button>
  <div class="dropdown-content">
    <a href="#">Direct Income</a>
     <a href="#">Level Income</a>
      <a href="#">Level Income View</a>
       <a href="#">Single Leg Income</a>
    
  </div>
</div>
<div class="dropdown">
  <button class="dropbtn">Fund</button>
  <div class="dropdown-content">
    <a href="#">Add Fund</a>
    <a href="#">Send Fund</a>
    <a href="#">Add Fund Detail</a>
   
  </div>
</div>
<div class="dropdown">
  <button class="dropbtn">Withdraw</button>
  <div class="dropdown-content">
    <a href="#">Wallet Withdraw Request</a>
    <a href="#">Wallet Withdraw Summary</a>
    <a href="#">Income and Withdraw Summary</a>
  </div>
</div>
<div class="dropdown">
  <button class="dropbtn">Transactions</button>
  <div class="dropdown-content">
      <a href="#">Main Wallet</a>
      <a href="#">GNI Wallet</a>
   
  </div>
</div>

<div class="dropdown">
  <button class="dropbtn">Support</button>
  <div class="dropdown-content">
    <a href="#">Add Request</a>
    <a href="#">View Request</a>
    
  </div>
</div>
<div class="dropdown">
  <button class="dropbtn"><a style="color:white;" href="index.php">logout</a></button>
  <div class="dropdown-content">
    
    
  </div>
</div>
<!--<button class="tablink"><a style="text-decoration: none;" href="register.php">Create New User</a></button>
<button class="tablink"><a style="text-decoration: none;" href="index.php" >Logout</a></button>-->


     
</body>
</html> 

