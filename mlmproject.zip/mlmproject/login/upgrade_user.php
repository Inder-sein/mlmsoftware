<?php require_once('../db.php');
 
 require_once ('userClass.php');
 require_once ('checkheader.php');
 $userData = $_SESSION['user'];
?>
<?php
 $user = new user();

if (isset($_POST["upgrade"])){
    extract($_POST);
} {
  
    
     $value = $user->extract_post($db,$_POST);
    extract($value);
  
    // Sponsor id check condition 
    $sponsercheck = mysqli_num_rows(mysqli_query($db, "select user_id from `user` where `user_id` = '$userid'"));
    if ($sponsercheck == 0){
        $_SESSION["upgrade"] = array("msg" => "User ID is not valid please check and try again Later.", "status" => false);
        echo "<script type='text/javascript'> document.location = 'welcome.php'; </script>";
        exit;
    }
  
    
    
    
    $total = $user->getWallet($db,$userData['user_id']);
    if ($total<1000) {
        $_SESSION["upgrade"] = array("msg" => "Your Not sufficent balance for this transaction.", "status" => "false");
//        header("location:../add_fund.php");
        echo "<script type='text/javascript'> document.location ='welcome.php'; </script>";
        exit;
        die;
    }
    
      $checkpad = $user->getUserUserStatus($db,$userid);
    if($checkpad =='paid')
    {
      $_SESSION["upgrade"] = array("msg" => "This User ID is already upgraded please check and try again later.", "status" => false);
        echo "<script type='text/javascript'> document.location = 'welcome.php'; </script>";
        exit;  
    }
    
   
     $upgrade_user = "INSERT INTO `wallet`(`user_id`,`amount`,`from_user_id`,`description`,`level`,`type`) VALUES ('".$userData['user_id']."','1000','123654','Upgrade_user','first','0')";
      $run = mysqli_query($db,$upgrade_user);
       
     
    
     $status = "UPDATE `user` SET `status` = 'paid', `amount` = '1000'  WHERE user_id = '$userid'";
      $run = mysqli_query($db,$status);
       header('location:welcome.php');
       $_SESSION["upgrade"] = array("msg" => "Enter User has been upgraded.", "status" => true);
        echo "<script type='text/javascript'> document.location = 'welcome.php'; </script>";
        exit;
}

   
?>

 