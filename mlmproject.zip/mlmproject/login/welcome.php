<?php 
require_once('../db.php');
require_once('header.php');
require_once ('checkheader.php');
require_once ('userClass.php');


?>


<!DOCTYPE html>
<html>
    <head>
        <style>
            table{
                text-align: center;
            }
            a
            {
                text-decoration: none;
                color:black;
            }
            .detail {
    padding: 0px 0px 0px 23px;
    margin: 0px 0px -30px;
}
            
.form{
    text-align: center;
}
        </style>

</head>
<body>
  

    <div class="content" >
        
        <br><br>
        <div class="detail"> </div>  <center> <table border="solid" cellspacing="0">
            
                 <tr>
                <th>Name</th>
                <th>User ID</th>
                <th>Role</th>
                <th>Phone Number</th>
                <th>Email Address</th>
                <th>Father Name</th>
                <th>Sponsor</th>
                <th>Position</th>
                <th>Sponsor By</th>
                <th>Address</th>
                <th>City</th>
                <th>Creation Date</th>
                <th>Updatetion Date</th>
                  
                
                
            </tr>
            <tr>
                <td><?php echo $name; ?></td>
                <td><?php echo $user_id; ?></td>
                <td><?php echo $role; ?></td>
                <td><?php echo $phone; ?></td>
                <td><?php echo $email; ?></td>
                <td><?php echo $father_name; ?></td>
                <td><?php echo $sponsorr; ?></td>
                <td><?php echo $position; ?></td>
                <td><?php echo $sponser_by; ?></td>
                <td><?php echo $address; ?></td>
                <td><?php echo $city; ?></td>
                <td><?php echo $creationDate; ?></td>
                <td><?php echo $updatetionDate; ?></td>
                
               
                
            </tr>
           
       
            
            
        </table>
        
            <p>Total Amount =><?php
                            $query = "SELECT sum(amount) as sumAB FROM  `wallet` where `user_id`='$user_id' and `type`='1'";
                            $sumAB = mysqli_fetch_array(mysqli_query($db, $query));
                            if (isset($sumAB['sumAB'])) {
                                echo 'Rs. ' . $sumAB['sumAB'];
                            } else {
                                echo 'Rs. 0';
                            }
                            
//                             $name = "SELECT sum(amount) as sumAB FROM  `wallet` where `user_id`='$user_id' and `type`='1'";
//                            $sumAB = mysqli_fetch_array(mysqli_query($db, $query));
//                            if (isset($sumAB['sumAB'])) {
//                                echo 'Rs. ' . $sumAB['sumAB'];
//                            } else {
//                                echo 'Rs. 0';
//                            }
                            ?>
                
            </p> 
            <p>Bakaya Rashi =><?php
               $user = new user();
                   $total = $user->getWallet($db,$userData['user_id']);
                   echo $total;
                   
            ?></p>
        </center>
        
        
        
        
     
        
    
    
    </h1></div>
    <br><br>
    <div class="form">
        
        <form method="post" action="upgrade_user.php">
            <h2> Topup User </h2>
            <input type="text" placeholder="User ID" name="userid" required="true"><br><br>
            <?php  if(isset($_SESSION["upgrade"]))
          if($_SESSION["upgrade"]["status"]== false) echo "<p style='color:red' class='false'>" . $_SESSION["upgrade"]["msg"]. "</p>";  ?>
      <?php if(isset($_SESSION["upgrade"]))
          if($_SESSION["upgrade"]["status"]==true) echo "<p style='color:#4CAF50' class='true'>" . $_SESSION['upgrade']['msg']. "</p>";unset($_SESSION["upgrade"]); ?>
           
            <button style="width:50%;" type="submit" name="upgrade">Upgrade User</button>
            
            
        </form>   
  
    </div>

</body>
</html>
     
           <head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}

/* Full-width input fields */
input[type=text], input[type=password] {
    width: 50%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
    text-align: center;
}

/* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 20px 20px;
    margin: 10px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

button:hover {
    opacity: 0.8;
}
.container {
    padding: 50px;
}
</style>
</head>