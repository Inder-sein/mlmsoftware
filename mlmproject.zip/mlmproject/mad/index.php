<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Madbrains</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  
  
      <link rel="stylesheet" href="css/style.css">
      <style>
          
          a{
              text-decoration: none;
          }
      </style>
  
</head>

<body>

  <main>
   <section class="main">
      <div class="container mainContent">
         <h1>Welcome to GNI WEB SOLUTION</h1>

         <p>Your Form Is Successfully Submitted</p>

         <button class="about"><a href="../index.php">GO TO Register Form</a></button>
      </div>
   </section>
  </main>

  <section class="aboutSection">
   <div class="container aboutContent">

      <h1>Welcome to GNI WEB SOLUTION</h1>

      <p>"Your Form Is Successfully Submitted"</p>


      <button class="home">Home</button>

   </div>
  </section>
  
  

    <script  src="js/index.js"></script>




</body>

</html>
