<?php
   require_once 'db.php';
   require_once 'userClass.php';
?>
<?php
$user = new useradmin();

if (isset($_POST["register"])) {
    extract($_POST);
} {
  
    if (in_array(" ", $_POST)) {
        $_SESSION["register"] = array("msg" => "All fields are required.", "status" => false);
        header("Location:index.php");exit();
    }
     $value = $user->extract_post($db, $_POST);
    extract($value);
    // Sponsor id check condition 
    $sponsercheck = mysqli_num_rows(mysqli_query($db, "select user_id from `user` where `user_id` = '$sponsor'"));
    if ($sponsercheck == 0) {
        $_SESSION["register"] = array("msg" => "Sponser id is not valid please check and try again Later.", "status" => false);
        header("location:index.php");exit();
    }
       $rightSponsor = $under_place;



    $spcheckk = mysqli_num_rows(mysqli_query($db, "select user_id from `user` where `sponsor` = '$under_place' and `position`='$position_user'"));

    if ($spcheckk > 0) {

        $_SESSION["register"] = array("msg" => "Sorry your under place id is not valid please choose another one.", "status" => false);

          echo "<script type='text/javascript'> document.location = 'index.php'; </script>";

        exit;

    }
    
      $rightSponsor = $user->getvalidSponsor($db, $sponsor, $position_user);
// var_dump ($rightSponsor); die;
     
    // Sponsor id check condition 

    $spcheck = mysqli_num_rows(mysqli_query($db, "select user_id from `user` where `user_id` = '$sponsor'"));

    if ($spcheck == 0) {

        $_SESSION["register"] = array("msg" => "Sponser id is not valid please check and try again.", "status" => false);

          echo "<script type='text/javascript'> document.location = 'index.php'; </script>";

        exit;

    }
    
 
      if ($password != $cpassword) {
       $_SESSION["register"] = array("msg" => "Sorry your confirm password is not match with password .", "status" => false);
       header("Location:index.php");
       exit();
   }
  
    $userId = $user->getUserIdForRegister($db);  
    $master = rand(1000, 9999); 
    $uidd = $userId;
    $datecurrent = date('Y-m-d H:i:s');
   $query= "INSERT INTO `user`(`user_id`,`role`,`name`,`sponsor`,`sponser_by`,`phone`, `email`,`address`,`password`,`position`) VALUES ('   $userId','user','$name','$rightSponsor','$sponsor','$phone','$email','$address','$password','$position_user')";
   $run = mysqli_query($db,$query);
   
   $send = "INSERT INTO `wallet`(`user_id`, `amount`, `description`, `type`,`from_user_id`,`level`) VALUES ('$userId','50','level_income','1','$sponsor','1')";
   $run = mysqli_query($db,$send);
//    header('Location:mad/index.php');
   $loop = false;
  
   $sponsor1 = $rightSponsor;
   
   $currentSponsor = $rightSponsor;
 
   
   while ($loop == false)
   {
        if($sponsor1 == "admin" or $sponsor1 == "")
       {
           $loop = true;
           
           break;
       }
       mysqli_query($db,"INSERT INTO `downline_count`(`tag_sponsor`, `sponsor`, `user_id`, `position`,`level`) VALUES ('$sponsor1','$currentSponsor','$userId','$position_user','')");
       
      
       
       $sopnsorget = mysqli_fetch_array(mysqli_query($db,"SELECT `sponsor`,`position` FROM `user` WHERE `user_id` = '$sponsor1'"));
       
       $sponsor1 = $sponsorget['sponsor'];
       
       $position_user = $sponsorget['position'];
   }
    
   $loop1 = false;
   
   $sponsor11 = $sponsor;
   
   $currentSponsor1 = $sponsor;
   
   $lv = 1;
   
   while ($loop1 == false )
   {
        if($sponsor11 == "admin" or $sponsor11 == "" or $sponsor11 == "Admin"){
           
           $loop1 = true;
           
           break;
       }
       
       mysqli_query($db,"INSERT INTO `level_downline`(`sponsor_by`, `user_id`, `level`)VALUES('$sponsor11','$userId','$lv')");
       
      
       $sponsorget1 = mysqli_fetch_array(mysqli_query($db, "SELECT `sponsor_by` FROM `user` where `user_id`='$sponsor11'"));
       
       $sponsor11 = $sponsorget1['sponsor_by'];
       
       $lv++;
   }    
    
           
    header('Location:mad/index.php');
}
?>        